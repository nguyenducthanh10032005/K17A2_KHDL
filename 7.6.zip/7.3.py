result=5
print('result',result)
result-=1
print('result',result)
result+=3
print('result',result)
result= - result
print('result',result)
result= True
print('result',result)